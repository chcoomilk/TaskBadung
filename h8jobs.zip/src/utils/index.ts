export default class Utils {
    static getRandomNumber(max: number) {
        return Math.floor(Math.random() * max);
    }
};